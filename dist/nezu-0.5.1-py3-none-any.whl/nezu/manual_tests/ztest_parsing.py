from nezu import say


class Dog:
    def sit(self):
        pass


say()
