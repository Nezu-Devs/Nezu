from ..nezu import nezu, say, dbg

nezu(1, color=True)

x = 3
y = 5
z = 7

say('yo',bp=6)
say('kupa',bp=5)
dbg('y','z', bp=7)
dbg('x')



