from ..nezu import nezu, dbg

nezu(1,color=1)

a = 'a'*69
b = 'b'*70
c = 'c'*80
biggus_dickus_1 = '1'*55
biggus_dickus_2 = '2'*56
dbg('a','b','c','biggus_dickus_1','biggus_dickus_2')
