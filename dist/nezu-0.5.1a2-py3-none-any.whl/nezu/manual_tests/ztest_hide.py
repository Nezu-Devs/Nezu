# file.py
from ..nezu import dbg


dbg('egg', hide=1)
dbg('ham', hide=2)
dbg('spam', hide=3)
dbg('bacon', hide=4)
dbg('lobster', hide=5)
