def cli():
    from nezu import nezu

    nezu(1)
