from nezu import dbg


class Dog:
    def sit(self):
        pass


dbg()
