# file.py
from ..nezu import nezu, say

nezu(1,1)

say('egg')
