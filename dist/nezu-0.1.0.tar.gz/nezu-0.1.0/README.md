# Nezu
Elegant logging and debuging module

## TO DO
- [ ] add class method support?
- [ ] add coloring.