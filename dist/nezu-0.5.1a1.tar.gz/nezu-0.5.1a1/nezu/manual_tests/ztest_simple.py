# file.py
from nezu import dbg

x = 13
dbg('x')
