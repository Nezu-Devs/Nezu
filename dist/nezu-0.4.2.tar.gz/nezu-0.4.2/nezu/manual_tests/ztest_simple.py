# file.py
from nezu import say

x = 13
say('x')
